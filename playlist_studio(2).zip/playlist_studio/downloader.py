"""
downloader.py

The actual work: given a normalized track list (from spotify_meta.py),

  1. SORT     - move any matching files already sitting in --scan
                folders into the output folder.
  2. SEARCH   - find each missing track on YouTube via yt-dlp, picking
                the search result whose duration is closest to Spotify's
                reported duration (falls back to the top result if no
                duration data is available -- never worse than a blind
                pick).
  3. DOWNLOAD - pull the best available audio stream and convert it
                with ffmpeg.
  4. TAG      - write real title/artist/album/track#/year from Spotify's
                metadata (not guessed off the YouTube title), plus embed
                Spotify's actual cover art -- not the YouTube thumbnail.
  5. REPORT   - every step reports into a shared job dict that the Flask
                layer polls, and failures are written to a text file too.

A note on audio quality: this can only ever be as good as what YouTube
actually has for a given upload -- typically ~128-160kbps Opus/AAC, sometimes
higher. Choosing FLAC or WAV avoids a second lossy re-encode (no extra
generation loss, and it's a safe container for large embedded artwork),
but it cannot restore detail that was never in the source stream. There's
no way around that without a licensed, lossless source.

yt_dlp / mutagen are imported lazily (inside functions) so this module --
and the Flask app that imports it -- can still load and run even before
`pip install -r requirements.txt` has been run, and so a missing
dependency turns into a friendly in-app message instead of a crash.
"""

import os
import re
import shutil
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

from spotify_meta import fetch_cover_bytes, sanitize_filename

AUDIO_EXTS = (".mp3", ".flac", ".m4a", ".opus", ".wav", ".ogg")
BOT_CHECK_PHRASES = ("sign in to confirm", "confirm you're not a bot", "confirm youre not a bot")


# --------------------------------------------------------------------------
# Environment check (powers the "Setup" panel in the UI)
# --------------------------------------------------------------------------

def check_environment() -> dict:
    status = {}

    try:
        import yt_dlp
        status["yt_dlp"] = {"ok": True, "detail": getattr(yt_dlp.version, "__version__", "installed")}
    except ImportError:
        status["yt_dlp"] = {"ok": False, "detail": "not installed -- run setup"}

    try:
        import mutagen
        status["mutagen"] = {"ok": True, "detail": getattr(mutagen, "version_string", "installed")}
    except ImportError:
        status["mutagen"] = {"ok": False, "detail": "not installed -- run setup"}

    try:
        import spotify_scraper  # noqa: F401
        status["spotify_scraper"] = {"ok": True, "detail": "installed"}
    except ImportError:
        status["spotify_scraper"] = {"ok": False, "detail": "not installed -- run setup"}

    ffmpeg_path = shutil.which("ffmpeg")
    status["ffmpeg"] = {
        "ok": bool(ffmpeg_path),
        "detail": ffmpeg_path or "not found on PATH -- required for every format",
    }
    return status


# --------------------------------------------------------------------------
# Sorting already-downloaded files in
# --------------------------------------------------------------------------

def find_existing_file(folder: str, safe_name: str):
    if not os.path.isdir(folder):
        return None
    for ext in AUDIO_EXTS:
        candidate = os.path.join(folder, safe_name + ext)
        if os.path.isfile(candidate):
            return candidate
    return None


def sort_existing_files(scan_dirs, dest_folder, expected_names, log=lambda m: None):
    moved = 0
    for scan_dir in scan_dirs:
        scan_dir = (scan_dir or "").strip()
        if not scan_dir or not os.path.isdir(scan_dir):
            continue
        if os.path.abspath(scan_dir) == os.path.abspath(dest_folder):
            continue
        for filename in os.listdir(scan_dir):
            full_path = os.path.join(scan_dir, filename)
            if not os.path.isfile(full_path):
                continue
            base_name, ext = os.path.splitext(filename)
            if ext.lower() not in AUDIO_EXTS:
                continue
            if base_name.lower() in expected_names:
                dest_path = os.path.join(dest_folder, filename)
                if os.path.exists(dest_path):
                    continue
                try:
                    shutil.move(full_path, dest_path)
                    log(f"Sorted in from {scan_dir}: {filename}")
                    moved += 1
                except (PermissionError, OSError):
                    log(f"Locked/unavailable, skipped: {filename}")
    return moved


# --------------------------------------------------------------------------
# YouTube search + pick
# --------------------------------------------------------------------------

def _is_bot_check_error(exc) -> bool:
    msg = str(exc).lower()
    return any(p in msg for p in BOT_CHECK_PHRASES)


def _build_ydl_extra_opts(options: dict) -> dict:
    opts = {}
    browser = (options.get("cookies_browser") or "none").strip().lower()
    if browser and browser != "none":
        opts["cookiesfrombrowser"] = (browser,)
    return opts


def _fetch_url_bytes(url: str, referer: str = "") -> bytes:
    """Generic binary fetch with browser + referer headers. Raises on
    failure (rather than swallowing it) so callers can log the real reason."""
    from spotify_meta import _headers_for
    headers = _headers_for(referer)
    try:
        import httpx
        resp = httpx.get(url, timeout=15, follow_redirects=True, headers=headers)
        resp.raise_for_status()
        return resp.content
    except ImportError:
        pass
    import requests
    resp = requests.get(url, timeout=15, headers=headers)
    resp.raise_for_status()
    return resp.content


def _best_yt_thumbnail(thumbnails) -> str | None:
    """yt-dlp flat-search entries carry a `thumbnails` list of dicts (often
    unsorted, not all with width/height). Picks the largest available, or
    just the last one if none report dimensions."""
    if not thumbnails or not isinstance(thumbnails, list):
        return None
    def area(t):
        return (t.get("width") or 0) * (t.get("height") or 0)
    best = max(thumbnails, key=area, default=None)
    return best.get("url") if best else None


class YouTubeResolveError(Exception):
    """User-facing error for anything that goes wrong resolving a YouTube link."""


_YT_TITLE_NOISE_RE = re.compile(
    r"\s*[\(\[]\s*(official\s*(music\s*)?video|official\s*audio|official|"
    r"lyrics?(\s*video)?|audio|hd|hq|4k|visualizer|mv|full\s*video)\s*[\)\]]\s*",
    re.IGNORECASE,
)


def _clean_yt_title(title: str) -> str:
    cleaned = _YT_TITLE_NOISE_RE.sub(" ", title or "")
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    return cleaned or (title or "Unknown Title")


def _split_artist_title(raw_title: str, uploader: str):
    """YouTube gives us one title string, not separate artist/title fields.
    Try the common 'Artist - Title' convention first; fall back to the
    channel name as artist (stripping YouTube's auto-generated channels'
    trailing ' - Topic', since that's the channel name, not the artist tag)."""
    title = _clean_yt_title(raw_title)
    for sep in (" - ", " \u2013 ", " \u2014 "):
        if sep in title:
            left, right = (p.strip() for p in title.split(sep, 1))
            if left and right:
                return left, right
    artist = uploader or "Unknown Artist"
    if artist.lower().endswith(" - topic"):
        artist = artist[: -len(" - Topic")].strip()
    return artist, title


def resolve_youtube_url(url: str) -> dict:
    """Resolve a plain YouTube video or playlist link into the same track
    shape spotify_meta.resolve_spotify_url produces, so it flows through
    the exact same preview/download/tag pipeline. Each track carries a
    `video_url` field -- download_one_track uses that directly instead of
    searching, since we already know exactly which video it is."""
    import yt_dlp
    opts = {"quiet": True, "no_warnings": True, "skip_download": True, "extract_flat": "in_playlist"}
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=False)
    except Exception as e:
        raise YouTubeResolveError(f"Couldn't read that YouTube link: {e}")

    if not info:
        raise YouTubeResolveError("Couldn't read that YouTube link.")

    entries = info.get("entries")
    if entries:
        raw_items = [e for e in entries if e]
        playlist_name = info.get("title") or "YouTube Playlist"
    else:
        raw_items = [info]
        playlist_name = None

    if not raw_items:
        raise YouTubeResolveError("That YouTube link didn't have any videos in it.")

    tracks = []
    for i, item in enumerate(raw_items, start=1):
        video_id = item.get("id")
        video_url = item.get("url") or item.get("webpage_url") or (
            f"https://www.youtube.com/watch?v={video_id}" if video_id else None
        )
        if not video_url:
            continue
        uploader = item.get("uploader") or item.get("channel") or ""
        artist, title = _split_artist_title(item.get("title") or "Unknown Title", uploader)
        duration = item.get("duration")
        duration_ms = int(duration * 1000) if isinstance(duration, (int, float)) else None
        thumb = item.get("thumbnail") or _best_yt_thumbnail(item.get("thumbnails"))
        tracks.append({
            "index": i,
            "title": title,
            "first_artist": artist,
            "all_artists": artist,
            "album": playlist_name or "",
            "year": None,
            "duration_ms": duration_ms,
            "explicit": False,
            "preview_url": None,
            "cover_art": thumb,
            "safe_name": sanitize_filename(f"{artist} - {title}"),
            "video_url": video_url,
        })
        # Re-number after any skipped (video_url-less) entries so indices stay contiguous.
        tracks[-1]["index"] = len(tracks)

    if not tracks:
        raise YouTubeResolveError("Couldn't get playable video URLs from that link.")

    name = playlist_name or tracks[0]["title"]
    cover_art = tracks[0]["cover_art"]
    owner = info.get("uploader") or info.get("channel")
    return {
        "source": "youtube",
        "type": "playlist" if len(tracks) > 1 else "video",
        "name": name,
        "owner": owner,
        "cover_art": cover_art,
        "total": len(tracks),
        "tracks": tracks,
    }


def search_candidates(query: str, n: int, extra_opts: dict):
    import yt_dlp
    opts = {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
        "noplaylist": True,
        "extract_flat": "in_playlist",
        **extra_opts,
    }
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(f"ytsearch{n}:{query}", download=False)
        return (info or {}).get("entries") or []


# Title keywords that usually signal a DIFFERENT version than the real
# studio track: clean/radio edits, karaoke backing tracks, covers, sped-up
# "tiktok" reuploads, hour-long loops, etc. Each is only counted against a
# candidate if the real Spotify title doesn't *already* contain that word --
# e.g. a track that is genuinely titled "... - Remix" shouldn't be punished
# for a YouTube result that (correctly) says "Remix" too.
_EDIT_PENALTIES = {
    "clean version": 40, "clean edit": 40, "clean": 32, "radio edit": 34,
    "radio version": 34, "censored": 40, "no cussing": 40, "edited version": 30,
    "instrumental": 42, "karaoke": 42, "backing track": 38, "acapella": 30,
    "a cappella": 30, "8d audio": 30, "8d": 22, "nightcore": 36, "sped up": 26,
    "speed up": 26, "slowed": 26, "slowed + reverb": 26, "slowed and reverb": 26,
    "reverb": 14, "tiktok": 16, "1 hour": 55, "one hour": 55, "10 hours": 60,
    "loop": 22, "extended mix": 10, "reaction": 45, "type beat": 45,
    "cover": 28, "tribute": 28, "karaoke version": 42,
}
# YouTube auto-generates a "<Artist> - Topic" channel per artist straight
# from their official releases -- one of the most reliable "this is the
# real, unedited studio upload" signals available without an API key.
_TRUSTED_CHANNEL_SUFFIX = " - topic"
DURATION_WEIGHT = 2.0  # points lost per second away from Spotify's duration


def _score_entry(entry, target_s, real_title_lower, first_artist_lower, prefer_explicit):
    title = (entry.get("title") or "").lower()
    channel = (entry.get("channel") or entry.get("uploader") or "").lower()
    duration = entry.get("duration")

    score = 0.0
    if isinstance(duration, (int, float)) and target_s:
        score -= abs(duration - target_s) * DURATION_WEIGHT
    elif target_s:
        score -= 25  # unknown duration is a mild penalty, not disqualifying

    for keyword, penalty in _EDIT_PENALTIES.items():
        if keyword in title and keyword not in real_title_lower:
            score -= penalty

    if channel.endswith(_TRUSTED_CHANNEL_SUFFIX):
        score += 12
    elif first_artist_lower and first_artist_lower in channel:
        score += 6

    if prefer_explicit and ("explicit" in title or "explicit" in channel):
        score += 4
    if prefer_explicit and "clean" in title and "clean" not in real_title_lower:
        score -= 10  # extra nudge: explicit tracks should really avoid "clean" reuploads

    return score


def pick_best_entry(entries, target_duration_ms, real_title="", first_artist="", prefer_explicit=False):
    """Pick the entry that best matches the real track -- weighing duration
    closeness most heavily, then penalizing title keywords that suggest a
    different edit/version (unless the real title uses that word itself),
    then a small trust bonus for known-official artist channels."""
    entries = [e for e in entries if e]
    if not entries:
        return None
    target_s = (target_duration_ms / 1000.0) if target_duration_ms else None
    real_title_lower = (real_title or "").lower()
    first_artist_lower = (first_artist or "").lower()

    scored = [
        (_score_entry(e, target_s, real_title_lower, first_artist_lower, prefer_explicit), e)
        for e in entries
    ]
    scored.sort(key=lambda pair: pair[0], reverse=True)
    return scored[0][1]


# --------------------------------------------------------------------------
# Download + convert
# --------------------------------------------------------------------------

def download_and_convert(video_url, out_template, audio_format, quality,
                          extra_opts, progress_hook, pp_hook, should_cancel=None):
    import yt_dlp

    def guarded_progress_hook(d):
        # yt-dlp calls progress_hooks with no exception handling around them
        # (see downloader/common.py: FileDownloader._hook_progress), so
        # raising here is the documented, supported way to abort a download
        # that's already in flight -- not just skip ones that haven't started.
        if should_cancel and should_cancel():
            raise yt_dlp.utils.DownloadCancelled("Cancelled by user")
        progress_hook(d)

    postprocessors = [{"key": "FFmpegExtractAudio", "preferredcodec": audio_format}]
    if audio_format not in ("flac", "wav"):
        postprocessors[0]["preferredquality"] = quality

    opts = {
        # Explicit sort on top of yt-dlp's own default so the highest-
        # bitrate audio-only stream reliably wins on close calls.
        "format": "bestaudio/best",
        "format_sort": ["abr", "asr"],
        "outtmpl": out_template,
        "postprocessors": postprocessors,
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "progress_hooks": [guarded_progress_hook],
        "postprocessor_hooks": [pp_hook],
        **extra_opts,
    }
    with yt_dlp.YoutubeDL(opts) as ydl:
        ydl.download([video_url])


# --------------------------------------------------------------------------
# Tagging + cover art (mutagen) -- one path per container format
# --------------------------------------------------------------------------

def _sniff_image_mime(data: bytes) -> str:
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "image/png"
    return "image/jpeg"


def _tag_mp3(filepath, meta, track_number, cover_bytes):
    from mutagen.id3 import ID3, ID3NoHeaderError, TIT2, TPE1, TALB, TRCK, TDRC, APIC
    try:
        tags = ID3(filepath)
    except ID3NoHeaderError:
        tags = ID3()
    tags["TIT2"] = TIT2(encoding=3, text=meta["title"])
    tags["TPE1"] = TPE1(encoding=3, text=meta["all_artists"])
    tags["TALB"] = TALB(encoding=3, text=meta.get("album") or "")
    tags["TRCK"] = TRCK(encoding=3, text=str(track_number))
    if meta.get("year"):
        tags["TDRC"] = TDRC(encoding=3, text=str(meta["year"]))
    if cover_bytes:
        tags.delall("APIC")
        tags.add(APIC(encoding=3, mime=_sniff_image_mime(cover_bytes), type=3,
                       desc="Cover", data=cover_bytes))
    tags.save(filepath, v2_version=3)


def _tag_flac(filepath, meta, track_number, cover_bytes):
    from mutagen.flac import FLAC, Picture
    audio = FLAC(filepath)
    audio["title"] = meta["title"]
    audio["artist"] = meta["all_artists"]
    audio["album"] = meta.get("album") or ""
    audio["tracknumber"] = str(track_number)
    if meta.get("year"):
        audio["date"] = str(meta["year"])
    if cover_bytes:
        audio.clear_pictures()
        pic = Picture()
        pic.data = cover_bytes
        pic.type = 3
        pic.mime = _sniff_image_mime(cover_bytes)
        audio.add_picture(pic)
    audio.save()


def _tag_mp4(filepath, meta, track_number, cover_bytes):
    from mutagen.mp4 import MP4, MP4Cover
    audio = MP4(filepath)
    audio["\xa9nam"] = [meta["title"]]
    audio["\xa9ART"] = [meta["all_artists"]]
    audio["\xa9alb"] = [meta.get("album") or ""]
    audio["trkn"] = [(int(track_number), 0)]
    if meta.get("year"):
        audio["\xa9day"] = [str(meta["year"])]
    if cover_bytes:
        fmt = MP4Cover.FORMAT_PNG if _sniff_image_mime(cover_bytes) == "image/png" else MP4Cover.FORMAT_JPEG
        audio["covr"] = [MP4Cover(cover_bytes, imageformat=fmt)]
    audio.save()


def _tag_opus(filepath, meta, track_number, cover_bytes):
    import base64
    from mutagen.oggopus import OggOpus
    from mutagen.flac import Picture
    audio = OggOpus(filepath)
    audio["title"] = meta["title"]
    audio["artist"] = meta["all_artists"]
    audio["album"] = meta.get("album") or ""
    audio["tracknumber"] = str(track_number)
    if meta.get("year"):
        audio["date"] = str(meta["year"])
    if cover_bytes:
        pic = Picture()
        pic.data = cover_bytes
        pic.type = 3
        pic.mime = _sniff_image_mime(cover_bytes)
        audio["metadata_block_picture"] = [base64.b64encode(pic.write()).decode("ascii")]
    audio.save()


def _tag_wav(filepath, meta, track_number, cover_bytes):
    from mutagen.wave import WAVE
    from mutagen.id3 import TIT2, TPE1, TALB, TRCK, TDRC, APIC
    audio = WAVE(filepath)
    if audio.tags is None:
        audio.add_tags()
    audio.tags.add(TIT2(encoding=3, text=meta["title"]))
    audio.tags.add(TPE1(encoding=3, text=meta["all_artists"]))
    audio.tags.add(TALB(encoding=3, text=meta.get("album") or ""))
    audio.tags.add(TRCK(encoding=3, text=str(track_number)))
    if meta.get("year"):
        audio.tags.add(TDRC(encoding=3, text=str(meta["year"])))
    if cover_bytes:
        audio.tags.add(APIC(encoding=3, mime=_sniff_image_mime(cover_bytes), type=3,
                             desc="Cover", data=cover_bytes))
    audio.save()


_TAGGERS = {
    ".mp3": _tag_mp3,
    ".flac": _tag_flac,
    ".m4a": _tag_mp4,
    ".mp4": _tag_mp4,
    ".opus": _tag_opus,
    ".wav": _tag_wav,
}


def embed_metadata(filepath, meta, track_number, cover_bytes):
    ext = os.path.splitext(filepath)[1].lower()
    tagger = _TAGGERS.get(ext)
    if not tagger:
        return f"no tagger for {ext} files"
    try:
        tagger(filepath, meta, track_number, cover_bytes)
        return None
    except Exception as e:
        return f"{e.__class__.__name__}: {e}"


# --------------------------------------------------------------------------
# Per-track orchestration
# --------------------------------------------------------------------------

def _has_cover_art(filepath) -> bool:
    """Best-effort check for whether a file already has embedded cover art,
    so re-runs don't redundantly re-fetch art it already has -- but DO
    backfill it for files that were downloaded before art was working."""
    try:
        from mutagen import File as MutagenFile
        f = MutagenFile(filepath)
        if f is None:
            return False
        if getattr(f, "pictures", None):  # FLAC
            return True
        if f.tags is None:
            return False
        keys = list(f.tags.keys())
        if any(k.startswith("APIC") for k in keys):  # MP3 / WAV (ID3)
            return True
        if "covr" in f.tags:  # MP4 / M4A
            return True
        if "metadata_block_picture" in f.tags:  # Opus / Ogg
            return True
        return False
    except Exception:
        return False


def _acquire_and_apply_tags(filepath, track, safe_name, on_log, chosen=None):
    """Fetch cover art (Spotify first, then the matched YouTube video's own
    thumbnail if one is available) and (re)embed all tags. Shared by the
    fresh-download path and the already-have-this-file path, so a file that
    was downloaded before art was working gets backfilled on the next run
    instead of being skipped forever."""
    cover_bytes = None
    cover_source = None
    spotify_cover_url = track.get("cover_art")
    if spotify_cover_url:
        try:
            cover_bytes = fetch_cover_bytes(track)
            if cover_bytes:
                cover_source = "Spotify"
            else:
                on_log(f"Cover art fetch from Spotify returned nothing for {safe_name} (url: {spotify_cover_url}).")
        except Exception as e:
            on_log(f"Cover art fetch from Spotify failed for {safe_name}: {e.__class__.__name__}: {e}")
    else:
        on_log(f"No Spotify cover_art URL was resolved for {safe_name}.")

    if not cover_bytes and chosen:
        yt_thumb_url = chosen.get("thumbnail") or _best_yt_thumbnail(chosen.get("thumbnails"))
        if yt_thumb_url:
            try:
                cover_bytes = _fetch_url_bytes(yt_thumb_url, referer="https://www.youtube.com/")
                if cover_bytes:
                    cover_source = "YouTube thumbnail"
                else:
                    on_log(f"YouTube thumbnail fetch returned nothing for {safe_name}.")
            except Exception as e:
                on_log(f"YouTube thumbnail fetch failed for {safe_name}: {e.__class__.__name__}: {e}")

    if not cover_bytes:
        on_log(f"No cover art could be fetched for {safe_name} -- tagging without it.")

    track_number = track.get("index", 1)
    tag_err = embed_metadata(filepath, track, track_number, cover_bytes)
    if tag_err:
        on_log(f"Tagging issue for {safe_name}: {tag_err}")
    elif cover_bytes:
        on_log(f"Embedded cover art for {safe_name} (source: {cover_source}, {len(cover_bytes)} bytes).")
    return cover_bytes is not None


def download_one_track(track, out_dir, options, on_status, on_log, should_cancel=lambda: False):
    safe_name = track["safe_name"]

    existing = find_existing_file(out_dir, safe_name)
    if existing:
        if not _has_cover_art(existing):
            on_log(f"{safe_name} already exists but has no embedded cover art -- fetching and re-tagging it now.")
            _acquire_and_apply_tags(existing, track, safe_name, on_log)
        on_status("done", 100)
        on_log(f"Already have: {safe_name}")
        return True, None

    if should_cancel():
        on_status("skipped", 0)
        return True, None

    known_video_url = track.get("video_url")
    extra_opts = _build_ydl_extra_opts(options)
    if known_video_url:
        # This track came from a direct YouTube link, not a Spotify search --
        # we already know exactly which video it is, so skip matching entirely.
        chosen = {"url": known_video_url, "thumbnail": track.get("cover_art")}
    else:
        on_status("searching", 0)
        explicit = bool(track.get("explicit"))
        avoid_clean = bool(options.get("avoid_clean_edits", True)) and explicit
        explicit_hint = " explicit" if avoid_clean else ""
        queries = [
            f'{track["first_artist"]} - {track["title"]}{explicit_hint} audio',
            f'{track["first_artist"]} {track["title"]}{explicit_hint}',
            f'{track["title"]} {track["first_artist"]} official audio',
        ]

        smart_match = options.get("smart_match", True)
        n_candidates = 5 if smart_match else 1
        delay = float(options.get("request_delay", 0) or 0)

        chosen = None
        for attempt, q in enumerate(queries, start=1):
            try:
                entries = search_candidates(q, n_candidates, extra_opts)
                if smart_match:
                    chosen = pick_best_entry(
                        entries, track.get("duration_ms"),
                        real_title=track["title"], first_artist=track["first_artist"],
                        prefer_explicit=avoid_clean,
                    )
                else:
                    chosen = entries[0] if entries else None
            except Exception as e:
                if _is_bot_check_error(e):
                    on_log("YouTube asked for a sign-in check -- set 'Browser cookies' "
                           "in Advanced settings and try again.")
                    on_status("failed", 0)
                    return False, "YouTube bot-check triggered"
                on_log(f"Search attempt {attempt} errored: {e}")
            if chosen:
                break
            if delay:
                time.sleep(delay)

        if not chosen:
            msg = f"No YouTube match found for: {track['first_artist']} - {track['title']}"
            on_log(msg)
            on_status("failed", 0)
            return False, msg

    video_url = chosen.get("url") or f"https://www.youtube.com/watch?v={chosen.get('id')}"

    on_status("downloading", 0)
    out_template = os.path.join(out_dir, f"{safe_name}.%(ext)s")

    def progress_hook(d):
        status = d.get("status")
        if status == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate")
            done = d.get("downloaded_bytes")
            if total and done:
                on_status("downloading", round(done / total * 100, 1))
        elif status == "finished":
            on_status("converting", 100)

    def pp_hook(d):
        if d.get("status") == "started":
            on_status("converting", 100)

    try:
        download_and_convert(
            video_url, out_template, options["format"], options.get("quality", "0"),
            extra_opts, progress_hook, pp_hook, should_cancel=should_cancel,
        )
    except Exception as e:
        import yt_dlp
        if isinstance(e, yt_dlp.utils.DownloadCancelled):
            on_status("skipped", 0)
            return True, None
        if _is_bot_check_error(e):
            on_log("YouTube asked for a sign-in check -- set 'Browser cookies' "
                   "in Advanced settings and try again.")
            on_status("failed", 0)
            return False, "YouTube bot-check triggered"
        msg = f"Download failed for {track['first_artist']} - {track['title']}: {e}"
        on_log(msg)
        on_status("failed", 0)
        return False, msg

    final_path = find_existing_file(out_dir, safe_name)
    if not final_path:
        msg = f"Converted file not found for {safe_name} -- is ffmpeg installed?"
        on_log(msg)
        on_status("failed", 0)
        return False, msg

    on_status("tagging", 100)
    _acquire_and_apply_tags(final_path, track, safe_name, on_log, chosen=chosen)

    on_status("done", 100)
    on_log(f"Done: {os.path.basename(final_path)}")
    return True, None


# --------------------------------------------------------------------------
# M3U playlist export -- so the folder drops straight into any player in
# the original playlist order, not just as a pile of loose files.
# --------------------------------------------------------------------------

def write_m3u_playlist(out_dir, playlist_name, tracks, log=lambda m: None):
    lines = ["#EXTM3U"]
    found = 0
    for t in sorted(tracks, key=lambda x: x["index"]):
        path = find_existing_file(out_dir, t["safe_name"])
        if not path:
            continue
        found += 1
        duration_s = round((t.get("duration_ms") or 0) / 1000)
        display = f'{t["first_artist"]} - {t["title"]}'
        lines.append(f"#EXTINF:{duration_s},{display}")
        lines.append(os.path.basename(path))
    if found == 0:
        return None
    name = sanitize_filename(playlist_name or "Playlist") or "Playlist"
    m3u_path = os.path.join(out_dir, f"{name}.m3u8")
    try:
        with open(m3u_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        return m3u_path
    except OSError as e:
        log(f"Couldn't write the .m3u8 playlist file: {e}")
        return None


# --------------------------------------------------------------------------
# Job runner -- mutates a shared `jobs[job_id]` dict as it goes
# --------------------------------------------------------------------------

def _update_track(jobs, lock, job_id, idx, **fields):
    with lock:
        job = jobs.get(job_id)
        if not job:
            return
        t = job["tracks"].get(str(idx))
        if t is None:
            return
        for k, v in fields.items():
            if v is not None:
                t[k] = v


def _append_log(jobs, lock, job_id, msg):
    with lock:
        job = jobs.get(job_id)
        if not job:
            return
        job["log"].append(msg)
        if len(job["log"]) > 300:
            job["log"] = job["log"][-300:]


def run_job(job_id, tracks, out_dir, scan_dirs, options, jobs, jobs_lock, playlist_name="Playlist"):
    missing = []
    try:
        import yt_dlp  # noqa: F401
    except ImportError:
        missing.append("yt-dlp")
    try:
        import mutagen  # noqa: F401
    except ImportError:
        missing.append("mutagen")
    if missing:
        with jobs_lock:
            jobs[job_id]["status"] = "error"
            jobs[job_id]["log"].append(
                f"Missing dependency: {', '.join(missing)}. Run run.bat "
                "(or `pip install -r requirements.txt`) first, then try again."
            )
        return

    try:
        os.makedirs(out_dir, exist_ok=True)
    except OSError as e:
        with jobs_lock:
            jobs[job_id]["status"] = "error"
            jobs[job_id]["log"].append(f"Couldn't create output folder: {e}")
        return

    with jobs_lock:
        jobs[job_id]["status"] = "sorting"

    expected_names = {t["safe_name"].lower() for t in tracks}
    moved = sort_existing_files(
        scan_dirs, out_dir, expected_names,
        log=lambda m: _append_log(jobs, jobs_lock, job_id, m),
    )

    with jobs_lock:
        jobs[job_id]["sorted_in"] = moved
        jobs[job_id]["status"] = "downloading"
        # Anything sort_existing_files already placed counts as done up front.
        for t in tracks:
            if find_existing_file(out_dir, t["safe_name"]):
                tt = jobs[job_id]["tracks"].get(str(t["index"]))
                if tt:
                    tt["status"] = "done"
                    tt["percent"] = 100

    threads = max(1, min(int(options.get("threads", 3) or 3), 8))

    def is_cancelled():
        with jobs_lock:
            return bool(jobs.get(job_id, {}).get("cancel_requested"))

    def process(track):
        idx = track["index"]
        if is_cancelled():
            with jobs_lock:
                already_done = jobs[job_id]["tracks"].get(str(idx), {}).get("status") == "done"
            if not already_done:
                _update_track(jobs, jobs_lock, job_id, idx, status="skipped")
                return True, None

        def on_status(status, percent=None):
            _update_track(jobs, jobs_lock, job_id, idx, status=status, percent=percent)

        def on_log(msg):
            _append_log(jobs, jobs_lock, job_id, msg)

        # Always goes through download_one_track, even for files that
        # already exist on disk -- that check is fast (a filesystem stat +
        # a mutagen tag read) and it's what actually backfills missing
        # cover art on files downloaded before art was working. Skipping
        # it here for "already done" tracks was the reason art fixes never
        # took effect on a folder that had already been partly downloaded.
        return download_one_track(track, out_dir, options, on_status, on_log, should_cancel=is_cancelled)

    failed = []
    with ThreadPoolExecutor(max_workers=threads) as executor:
        futures = {executor.submit(process, t): t for t in tracks}
        for future in as_completed(futures):
            t = futures[future]
            try:
                ok, err = future.result()
            except Exception as e:
                ok, err = False, str(e)
            with jobs_lock:
                jobs[job_id]["completed"] += 1
                if not ok:
                    jobs[job_id]["failed_count"] += 1
                    failed.append({
                        "index": t["index"], "title": t["title"],
                        "artist": t["first_artist"], "error": err,
                    })

    m3u_path = write_m3u_playlist(
        out_dir, playlist_name, tracks,
        log=lambda m: _append_log(jobs, jobs_lock, job_id, m),
    )

    with jobs_lock:
        jobs[job_id]["failed_tracks"] = failed
        jobs[job_id]["m3u_path"] = m3u_path
        jobs[job_id]["status"] = "cancelled" if jobs[job_id].get("cancel_requested") else "done"

    if failed:
        try:
            with open(os.path.join(out_dir, "failed_tracks.txt"), "w", encoding="utf-8") as f:
                for item in failed:
                    f.write(f"{item['artist']} - {item['title']}: {item['error']}\n")
        except OSError:
            pass
