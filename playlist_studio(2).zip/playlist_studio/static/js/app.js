/* Playlist Studio -- frontend logic. No build step, no framework:
   plain fetch + DOM. All state lives in memory for the page session. */

let currentResolved = null;
let currentJobId = null;
let pollTimer = null;
let lastOutputDir = null;
let lastFailedTracks = [];
let previewAudio = null;
let previewBtnPlaying = null;

const THEMES = ['studio', 'nightdrive', 'vinyl', 'daylight'];

document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  checkEnvironment();
  updateQualityVisibility();
  wireEvents();
});

// ------------------------------------------------------------------ theme --

function initTheme() {
  let saved = null;
  try { saved = localStorage.getItem('ps_theme'); } catch (e) { /* ignore */ }
  const theme = THEMES.includes(saved) ? saved : 'studio';
  applyTheme(theme);
  document.querySelectorAll('.theme-swatch').forEach((btn) => {
    btn.addEventListener('click', () => applyTheme(btn.dataset.theme));
  });
}

function applyTheme(theme) {
  if (!THEMES.includes(theme)) theme = 'studio';
  document.documentElement.setAttribute('data-theme', theme);
  document.querySelectorAll('.theme-swatch').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.theme === theme);
  });
  try { localStorage.setItem('ps_theme', theme); } catch (e) { /* private browsing etc -- non-fatal */ }
}

// ---------------------------------------------------------------- wiring --

function wireEvents() {
  document.getElementById('setupToggle').addEventListener('click', () => {
    document.getElementById('setupPanel').classList.toggle('hidden');
  });

  document.getElementById('loadBtn').addEventListener('click', () => {
    const url = document.getElementById('urlInput').value.trim();
    if (url) resolveUrl(url);
  });
  document.getElementById('urlInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') document.getElementById('loadBtn').click();
  });

  document.getElementById('csvFallbackLink').addEventListener('click', () => {
    document.getElementById('csvInput').click();
  });
  document.getElementById('csvInput').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) resolveCsv(file);
    e.target.value = '';
  });

  document.getElementById('selectAll').addEventListener('change', (e) => {
    document.querySelectorAll('.track-check').forEach((cb) => { cb.checked = e.target.checked; });
    updateSelectAllLabel();
  });

  document.getElementById('formatSelect').addEventListener('change', updateQualityVisibility);

  document.getElementById('advancedToggle').addEventListener('click', () => {
    const panel = document.getElementById('advancedPanel');
    panel.classList.toggle('hidden');
    document.getElementById('advancedToggle').textContent =
      panel.classList.contains('hidden') ? 'Advanced settings' : 'Hide advanced settings';
  });

  document.getElementById('startBtn').addEventListener('click', onStartClicked);
  document.getElementById('cancelBtn').addEventListener('click', onCancelClicked);
  document.getElementById('openFolderBtn').addEventListener('click', onOpenFolderClicked);
  document.getElementById('retryBtn').addEventListener('click', onRetryClicked);
  document.getElementById('browseBtn').addEventListener('click', onBrowseClicked);

  document.getElementById('logToggle').addEventListener('click', () => {
    const log = document.getElementById('logConsole');
    log.classList.toggle('hidden');
    document.getElementById('logToggle').textContent =
      log.classList.contains('hidden') ? 'Show log' : 'Hide log';
  });
}

// -------------------------------------------------------------- helpers --

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str ?? '';
  return div.innerHTML;
}

function renderThumb(coverUrl, fallbackLabel) {
  const label = `<span class="track-thumb-fallback">${escapeHtml(String(fallbackLabel))}</span>`;
  if (!coverUrl) return `<div class="track-thumb">${label}</div>`;
  // onerror removes the broken <img> -- once it's gone, the CSS rule
  // `.track-thumb:has(img) .track-thumb-fallback { display:none }` stops
  // matching and the number shows through automatically, no JS state needed.
  return `<div class="track-thumb">
    <img src="${escapeHtml(coverUrl)}" alt="" loading="lazy" onerror="this.remove()">
    ${label}
  </div>`;
}

function formatDuration(ms) {
  if (!ms && ms !== 0) return '--:--';
  const totalSec = Math.round(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

function showToast(msg, isError = true) {
  let toast = document.getElementById('toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast';
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.classList.toggle('toast-error', isError);
  toast.classList.add('toast-show');
  clearTimeout(showToast._t);
  showToast._t = setTimeout(() => toast.classList.remove('toast-show'), 4500);
}

function showResolveError(msg) {
  const el = document.getElementById('resolveError');
  el.textContent = msg;
  el.classList.remove('hidden');
}

function clearResolveError() {
  document.getElementById('resolveError').classList.add('hidden');
}

// -------------------------------------------------------- setup / check --

async function checkEnvironment() {
  try {
    const res = await fetch('/api/environment');
    const status = await res.json();
    renderSetupPanel(status);
    const allOk = Object.values(status).every((s) => s.ok);
    if (!allOk) document.getElementById('setupPanel').classList.remove('hidden');
  } catch (e) {
    // Server just started, or unreachable for a moment -- not fatal.
  }
}

function renderSetupPanel(status) {
  const grid = document.getElementById('setupGrid');
  const labels = {
    yt_dlp: 'yt-dlp', mutagen: 'mutagen',
    spotify_scraper: 'spotifyscraper', ffmpeg: 'ffmpeg',
  };
  grid.innerHTML = Object.entries(status).map(([key, val]) => `
    <div class="setup-row ${val.ok ? 'ok' : 'bad'}">
      <span><span class="dot"></span>${labels[key] || key}</span>
      <span class="detail">${escapeHtml(val.detail)}</span>
    </div>
  `).join('');
}

// ------------------------------------------------------------- resolve --

async function resolveUrl(url) {
  setResolveLoading(true);
  try {
    const res = await fetch('/api/resolve', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Something went wrong.');
    onResolved(data);
  } catch (e) {
    showResolveError(e.message);
  } finally {
    setResolveLoading(false);
  }
}

async function resolveCsv(file) {
  setResolveLoading(true);
  try {
    const form = new FormData();
    form.append('file', file);
    const res = await fetch('/api/resolve_csv', { method: 'POST', body: form });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Something went wrong.');
    onResolved(data);
  } catch (e) {
    showResolveError(e.message);
  } finally {
    setResolveLoading(false);
  }
}

function setResolveLoading(loading) {
  const btn = document.getElementById('loadBtn');
  btn.disabled = loading;
  btn.textContent = loading ? 'Loading...' : 'Load';
}

function onResolved(data) {
  currentResolved = data;
  clearResolveError();
  renderPreview(data);
  document.getElementById('previewPanel').classList.remove('hidden');
  document.getElementById('resultsPanel').classList.add('hidden');
  document.getElementById('progressPanel').classList.add('hidden');
  document.getElementById('previewPanel').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function renderPreview(data) {
  document.getElementById('previewType').textContent = (data.type || 'playlist').toUpperCase();
  document.getElementById('previewName').textContent = data.name || 'Untitled';

  const subParts = [];
  if (data.owner) subParts.push(`by ${data.owner}`);
  subParts.push(`${data.tracks.length} track${data.tracks.length === 1 ? '' : 's'}`);
  if (data.source === 'csv') subParts.push('from CSV');
  document.getElementById('previewSub').textContent = subParts.join(' \u00b7 ');

  const cover = document.getElementById('previewCover');
  if (data.cover_art) {
    cover.src = data.cover_art;
    cover.style.visibility = 'visible';
  } else {
    cover.style.visibility = 'hidden';
  }

  document.getElementById('outputInput').value = data.suggested_output || '';

  const warnEl = document.getElementById('previewCoverWarning');
  const missing = data.tracks_missing_cover_url || 0;
  if (missing > 0) {
    warnEl.textContent = `Heads up: Spotify didn't return track-level art for ${missing} of ${data.tracks.length} track${data.tracks.length === 1 ? '' : 's'} (this happens when Spotify's fuller per-track data is unavailable and it falls back to lighter data). Those tracks will use the playlist/album cover instead of their own art.`;
    warnEl.classList.remove('hidden');
  } else {
    warnEl.classList.add('hidden');
  }

  renderTrackList(data.tracks);
}

function renderTrackList(tracks) {
  const container = document.getElementById('trackList');
  container.innerHTML = tracks.map((t) => `
    <div class="track-row">
      <div class="track-lead">
        <input type="checkbox" class="track-check" data-index="${t.index}" checked>
        <button class="preview-btn" data-preview="${t.index}" type="button"
          ${t.preview_url ? '' : 'disabled'} title="${t.preview_url ? 'Preview 30s' : 'No preview available'}">&#9654;</button>
      </div>
      ${renderThumb(t.cover_art, t.index)}
      <div class="track-info">
        <div class="track-title">${escapeHtml(t.title)}${t.explicit ? ' <span class="hint" style="display:inline">\u{1F51E}</span>' : ''}</div>
        <div class="track-artist">${escapeHtml(t.first_artist)}${t.album ? ' \u00b7 ' + escapeHtml(t.album) : ''}</div>
      </div>
      <span class="track-dur">${formatDuration(t.duration_ms)}</span>
    </div>
  `).join('');
  container.querySelectorAll('.track-check').forEach((cb) => {
    cb.addEventListener('change', updateSelectAllLabel);
  });
  container.querySelectorAll('.preview-btn').forEach((btn) => {
    btn.addEventListener('click', () => togglePreview(btn, tracks));
  });
  updateSelectAllLabel();
}

function togglePreview(btn, tracks) {
  const idx = Number(btn.dataset.preview);
  const track = tracks.find((t) => t.index === idx);
  if (!track || !track.preview_url) return;

  if (previewBtnPlaying === btn) {
    stopPreview();
    return;
  }
  stopPreview();

  previewAudio = new Audio(track.preview_url);
  previewAudio.volume = 0.9;
  previewAudio.addEventListener('ended', stopPreview);
  previewAudio.addEventListener('error', stopPreview);
  previewAudio.play().catch(() => stopPreview());
  btn.classList.add('playing');
  btn.innerHTML = '&#9724;';
  previewBtnPlaying = btn;
}

function stopPreview() {
  if (previewAudio) {
    previewAudio.pause();
    previewAudio = null;
  }
  if (previewBtnPlaying) {
    previewBtnPlaying.classList.remove('playing');
    previewBtnPlaying.innerHTML = '&#9654;';
    previewBtnPlaying = null;
  }
}

async function onBrowseClicked() {
  const btn = document.getElementById('browseBtn');
  const input = document.getElementById('outputInput');
  btn.disabled = true;
  try {
    const res = await fetch('/api/pick_folder', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ initial: input.value.trim() }),
    });
    const data = await res.json();
    if (data.path) input.value = data.path;
    else if (data.error) showToast(data.error);
  } catch (e) {
    showToast('Could not open a folder picker -- type the path instead.');
  } finally {
    btn.disabled = false;
  }
}

function updateSelectAllLabel() {
  const boxes = [...document.querySelectorAll('.track-check')];
  const checked = boxes.filter((b) => b.checked).length;
  const label = document.getElementById('selectAllLabel');
  const selectAll = document.getElementById('selectAll');
  if (boxes.length === 0) return;
  if (checked === boxes.length) {
    label.textContent = `All ${boxes.length} tracks selected`;
    selectAll.checked = true;
    selectAll.indeterminate = false;
  } else if (checked === 0) {
    label.textContent = `0 of ${boxes.length} tracks selected`;
    selectAll.checked = false;
    selectAll.indeterminate = false;
  } else {
    label.textContent = `${checked} of ${boxes.length} tracks selected`;
    selectAll.indeterminate = true;
  }
}

function updateQualityVisibility() {
  const format = document.getElementById('formatSelect').value;
  const field = document.getElementById('qualityField');
  field.classList.toggle('hidden', format === 'flac' || format === 'wav');
}

// -------------------------------------------------------------- download --

function collectSettings() {
  return {
    format: document.getElementById('formatSelect').value,
    quality: document.getElementById('qualitySelect').value,
    output_dir: document.getElementById('outputInput').value.trim(),
    scan_dirs: document.getElementById('scanInput').value,
    threads: parseInt(document.getElementById('threadsInput').value, 10) || 3,
    request_delay: parseFloat(document.getElementById('delayInput').value) || 0,
    cookies_browser: document.getElementById('cookiesSelect').value,
    smart_match: document.getElementById('smartMatchInput').checked,
    avoid_clean_edits: document.getElementById('avoidCleanInput').checked,
  };
}

async function onStartClicked() {
  if (!currentResolved) return;
  stopPreview();
  const selectedIdx = new Set(
    [...document.querySelectorAll('.track-check')]
      .filter((cb) => cb.checked)
      .map((cb) => Number(cb.dataset.index))
  );
  const tracks = currentResolved.tracks.filter((t) => selectedIdx.has(t.index));
  if (tracks.length === 0) {
    showResolveError('Select at least one track first.');
    return;
  }
  await startDownload(tracks, currentResolved.name, collectSettings());
}

async function startDownload(tracks, playlistName, settings) {
  const startBtn = document.getElementById('startBtn');
  startBtn.disabled = true;
  try {
    const res = await fetch('/api/download', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tracks, playlist_name: playlistName, ...settings }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Could not start the download.');

    currentJobId = data.job_id;
    document.getElementById('previewPanel').classList.add('hidden');
    document.getElementById('resultsPanel').classList.add('hidden');

    const progressPanel = document.getElementById('progressPanel');
    progressPanel.classList.remove('hidden');
    document.getElementById('statTotal').textContent = tracks.length;
    document.getElementById('statDone').textContent = '0';
    document.getElementById('overallFill').style.width = '0%';
    initProgressTrackList(tracks);
    progressPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });

    startPolling(currentJobId);
  } catch (e) {
    showToast(e.message);
    document.getElementById('previewPanel').classList.remove('hidden');
  } finally {
    startBtn.disabled = false;
  }
}

function initProgressTrackList(tracks) {
  const map = {};
  tracks.forEach((t) => {
    map[t.index] = { title: t.title, artist: t.first_artist, cover_art: t.cover_art, status: 'queued', percent: 0 };
  });
  renderProgressTrackList(map);
}

function renderProgressTrackList(tracksMap) {
  const container = document.getElementById('progressTrackList');
  const rows = Object.entries(tracksMap).sort((a, b) => Number(a[0]) - Number(b[0]));
  container.innerHTML = rows.map(([idx, t]) => `
    <div class="track-row">
      <span></span>
      ${renderThumb(t.cover_art, idx)}
      <div class="track-info">
        <div class="track-title">${escapeHtml(t.title)}</div>
        <div class="track-artist">${escapeHtml(t.artist)}</div>
      </div>
      <span class="track-status status-${t.status}">${statusLabel(t.status, t.percent)}</span>
    </div>
  `).join('');
}

function statusLabel(status, percent) {
  switch (status) {
    case 'queued': return 'Queued';
    case 'searching': return 'Searching';
    case 'downloading': return `${Math.round(percent || 0)}%`;
    case 'converting': return 'Converting';
    case 'tagging': return 'Tagging';
    case 'done': return 'Done';
    case 'failed': return 'Failed';
    case 'skipped': return 'Skipped';
    default: return status;
  }
}

// --------------------------------------------------------------- polling --

function startPolling(jobId) {
  if (pollTimer) clearInterval(pollTimer);
  pollOnce(jobId);
  pollTimer = setInterval(() => pollOnce(jobId), 1000);
}

async function pollOnce(jobId) {
  try {
    const res = await fetch(`/api/progress/${jobId}`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Lost track of that job.');
    renderProgress(data);
    if (['done', 'cancelled', 'error'].includes(data.status)) {
      clearInterval(pollTimer);
      pollTimer = null;
      renderResults(data);
    }
  } catch (e) {
    // Transient network hiccup on a local server -- next tick will retry.
  }
}

function renderProgress(data) {
  lastOutputDir = data.output_dir;
  const pct = data.total ? Math.round((data.completed / data.total) * 100) : 0;
  document.getElementById('overallFill').style.width = `${pct}%`;
  document.getElementById('statDone').textContent = data.completed;
  document.getElementById('statTotal').textContent = data.total;
  document.getElementById('statSorted').textContent = `${data.sorted_in} sorted in`;
  document.getElementById('statFailed').textContent = `${data.failed_count} failed`;

  const titles = {
    sorting: 'Sorting existing files in...',
    downloading: 'Downloading...',
    done: 'Done',
    cancelled: 'Cancelled',
    error: 'Something went wrong',
  };
  document.getElementById('progressTitle').textContent = titles[data.status] || 'Working on it...';

  renderProgressTrackList(data.tracks);

  const log = document.getElementById('logConsole');
  log.textContent = data.log.join('\n');
  if (!log.classList.contains('hidden')) log.scrollTop = log.scrollHeight;
}

function renderResults(data) {
  document.getElementById('progressPanel').classList.add('hidden');
  const resultsPanel = document.getElementById('resultsPanel');
  resultsPanel.classList.remove('hidden');

  lastFailedTracks = data.failed_tracks || [];
  const ok = data.total - data.failed_count;

  document.getElementById('resultsTitle').textContent =
    data.status === 'cancelled' ? 'Cancelled'
      : data.failed_count ? 'Finished, with a few misses'
      : 'All done';

  document.getElementById('resultsSummary').textContent =
    `${ok}/${data.total} tracks landed in ${data.output_dir}` +
    (data.sorted_in ? ` (${data.sorted_in} were already sorted in)` : '');

  const m3uEl = document.getElementById('resultsM3u');
  if (data.m3u_path) {
    m3uEl.textContent = `Playlist file written: ${data.m3u_path.split(/[\\/]/).pop()} -- drop the whole folder into any player.`;
    m3uEl.classList.remove('hidden');
  } else {
    m3uEl.classList.add('hidden');
  }

  const retryBtn = document.getElementById('retryBtn');
  const failedList = document.getElementById('failedList');
  if (lastFailedTracks.length) {
    retryBtn.classList.remove('hidden');
    failedList.innerHTML = lastFailedTracks.map((t) => `
      <div>${escapeHtml(t.artist)} - ${escapeHtml(t.title)}: ${escapeHtml(t.error || 'unknown error')}</div>
    `).join('');
  } else {
    retryBtn.classList.add('hidden');
    failedList.innerHTML = '';
  }

  resultsPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// -------------------------------------------------------------- actions --

async function onCancelClicked() {
  if (!currentJobId) return;
  const btn = document.getElementById('cancelBtn');
  btn.disabled = true;
  btn.textContent = 'Cancelling...';
  try {
    await fetch(`/api/cancel/${currentJobId}`, { method: 'POST' });
  } finally {
    btn.disabled = false;
    btn.textContent = 'Cancel';
  }
}

async function onOpenFolderClicked() {
  if (!lastOutputDir) return;
  try {
    const res = await fetch('/api/open_folder', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: lastOutputDir }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Could not open that folder.');
  } catch (e) {
    showToast(e.message);
  }
}

async function onRetryClicked() {
  if (!currentResolved || !lastFailedTracks.length) return;
  const failedIndices = new Set(lastFailedTracks.map((f) => f.index));
  const tracks = currentResolved.tracks.filter((t) => failedIndices.has(t.index));
  await startDownload(tracks, currentResolved.name, collectSettings());
}
