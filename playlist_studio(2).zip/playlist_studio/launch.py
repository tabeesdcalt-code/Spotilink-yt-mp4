"""
launch.py

Entry point for Playlist Studio. Starts the Flask server in a background
thread, then opens it as a real app window (no address bar, no browser
chrome) via pywebview -- or falls back to your default browser if
pywebview isn't installed.

This is also the entry point build_exe.bat wraps into a standalone
PlaylistStudio.exe with PyInstaller.
"""

import socket
import sys
import threading
import time
import webbrowser

HOST = "127.0.0.1"
PORT = 5757


def _port_is_free(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex((HOST, port)) != 0


def _find_port(preferred):
    if _port_is_free(preferred):
        return preferred
    for p in range(preferred + 1, preferred + 20):
        if _port_is_free(p):
            return p
    return preferred


def main():
    global PORT
    PORT = _find_port(PORT)

    from app import app  # local import so this file can be inspected without Flask installed yet

    server_thread = threading.Thread(
        target=lambda: app.run(host=HOST, port=PORT, debug=False, threaded=True, use_reloader=False),
        daemon=True,
    )
    server_thread.start()

    url = f"http://{HOST}:{PORT}/"

    # Give the dev server a moment to bind before pointing anything at it.
    for _ in range(50):
        if not _port_is_free(PORT):
            break
        time.sleep(0.1)

    try:
        import webview
        webview.create_window("Playlist Studio", url, width=880, height=980, min_size=(420, 600))
        webview.start()
    except ImportError:
        print(f"pywebview isn't installed, so opening {url} in your browser instead.")
        print("For a proper app window next time: pip install pywebview")
        webbrowser.open(url)
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            sys.exit(0)


if __name__ == "__main__":
    main()
