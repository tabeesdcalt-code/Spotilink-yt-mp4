"""
spotify_meta.py

Turns a Spotify link into a plain list of tracks -- no client ID,
no client secret, no Spotify Developer app, no login required for
public playlists/albums/tracks.

Primary path: the `spotifyscraper` package (PyPI: spotifyscraper,
import name: spotify_scraper). It bootstraps an anonymous token from
Spotify's own public embed pages and reads the same endpoints the web
player uses -- the same technique tools like this have used for years.
It only ever touches public metadata and Spotify's own ~30s preview
clips; it does not download full tracks or touch DRM, which is exactly
the boundary this app relies on (the actual songs come from a separate
YouTube search+download step in downloader.py).

Fallback path: parsing an Exportify (https://exportify.net) CSV export,
in case Spotify changes something upstream before the scraper catches
up, or a particular playlist just won't resolve.

Everything here is deliberately defensive about the exact shape of
third-party data: field lookups fall back through a few plausible
names/paths instead of assuming one fixed schema, since this whole
module rides on an unofficial, unversioned interface that can shift.
"""

import csv
import io
import re


# --------------------------------------------------------------------------
# Shared helpers
# --------------------------------------------------------------------------

INVALID_CHARS = '<>:"/\\|?*'


def sanitize_filename(name: str) -> str:
    for ch in INVALID_CHARS:
        name = name.replace(ch, "")
    name = name.strip().rstrip(".")
    return name[:150] if len(name) > 150 else name


def make_safe_name(artist: str, title: str) -> str:
    artist = (artist or "").strip()
    title = (title or "Unknown Title").strip()
    base = f"{artist} - {title}".strip(" -")
    return sanitize_filename(base) or "Unknown Track"


def _get(obj, *names, default=None):
    """Try several attribute/key names against either an object or a dict."""
    for name in names:
        if obj is None:
            break
        if isinstance(obj, dict):
            if name in obj and obj[name] is not None:
                return obj[name]
        else:
            val = getattr(obj, name, None)
            if val is not None:
                return val
    return default


def _best_image_url(images):
    """images: list of {url,width,height} (dict or object). Picks the largest."""
    if not images:
        return None
    best_url, best_area = None, -1
    for img in images:
        url = _get(img, "url")
        w = _get(img, "width", default=0) or 0
        h = _get(img, "height", default=0) or 0
        area = w * h
        if url and area >= best_area:
            best_url, best_area = url, area
    if best_url:
        return best_url
    # No dimensions given at all -- just take the first one with a URL.
    for img in images:
        url = _get(img, "url")
        if url:
            return url
    return None


def _collect_image_candidates(entity, out):
    """Append every image-shaped value found on `entity` into `out`."""
    for path in ("images", "cover", "covers"):
        val = _get(entity, path)
        if isinstance(val, (list, tuple)):
            out.extend(val)
        elif isinstance(val, str) and val:
            out.append({"url": val, "width": 0, "height": 0})


def _extract_cover(entity):
    """Pull the highest-resolution cover-art URL out of a track/album/
    playlist-shaped object. Checks the entity's own images AND its album's
    images (a track's own `images` can be a lower-res set than its album's,
    e.g. when only a 64x64 was attached at track level) and picks the
    largest across both rather than stopping at whichever is found first."""
    candidates = []
    _collect_image_candidates(entity, candidates)
    album = _get(entity, "album")
    if album is not None:
        _collect_image_candidates(album, candidates)
    return _best_image_url(candidates)


def _unwrap_playlist_track(item):
    """A Playlist's `.tracks` is a tuple of PlaylistTrack wrappers (each
    holding `.track`, `.added_at`, `.added_by`) -- NOT plain Track objects.
    Album.tracks, by contrast, already holds plain Track objects directly.
    `_get(item, "track", default=item)` handles both shapes in one line:
    it unwraps a PlaylistTrack, and is a no-op for anything that has no
    `.track` attribute of its own (a plain Track, or a CSV-sourced dict)."""
    return _get(item, "track", default=item)


def _extract_artists(track):
    artists_field = _get(track, "artists")
    names = []
    if isinstance(artists_field, (list, tuple)):
        for a in artists_field:
            name = _get(a, "name") if not isinstance(a, str) else a
            if name:
                names.append(name)
    single = _get(track, "artist")
    if not names and isinstance(single, str):
        names = [single]
    if not names:
        names = ["Unknown Artist"]
    return names


def _extract_year(entity):
    for path in ("release_date", "year", "released"):
        val = _get(entity, path)
        if val:
            return str(val)[:4]
    album = _get(entity, "album")
    if album is not None:
        for path in ("release_date", "year", "released"):
            val = _get(album, path)
            if val:
                return str(val)[:4]
    return None


def _normalize_track(track, index):
    title = _get(track, "name", "title", default="Unknown Title")
    artists = _extract_artists(track)
    first_artist = artists[0]
    all_artists = ", ".join(artists)

    album_obj = _get(track, "album")
    album_name = _get(album_obj, "name", default=None) or _get(track, "album_name", default="")

    cover = _extract_cover(track)
    year = _extract_year(track)
    duration_ms = _get(track, "duration_ms", "duration")
    explicit = bool(_get(track, "explicit", default=False))
    preview_url = _get(track, "preview_url")

    return {
        "index": index,
        "title": title,
        "first_artist": first_artist,
        "all_artists": all_artists,
        "album": album_name or "",
        "year": year,
        "duration_ms": duration_ms,
        "explicit": explicit,
        "preview_url": preview_url,
        "cover_art": cover,
        "safe_name": make_safe_name(first_artist, title),
    }


# --------------------------------------------------------------------------
# Primary path: spotifyscraper (no API key)
# --------------------------------------------------------------------------

class SpotifyResolveError(Exception):
    """Raised with a message that's safe to show directly in the UI."""


def _classify_url(url: str) -> str:
    url = url.strip()
    m = re.search(r"(playlist|album|track)[:/]([A-Za-z0-9]+)", url)
    if m:
        return m.group(1)
    if re.fullmatch(r"[A-Za-z0-9]{15,40}", url):
        return "track"  # bare ID, best guess
    raise SpotifyResolveError(
        "That doesn't look like a Spotify playlist, album, or track link."
    )


def resolve_spotify_url(url: str, max_tracks=None) -> dict:
    """
    Returns:
        {
          "source": "spotify",
          "type": "playlist" | "album" | "track",
          "name": str,
          "owner": str | None,
          "cover_art": str | None,
          "tracks": [ {index, title, first_artist, all_artists, album,
                       year, duration_ms, cover_art, safe_name}, ... ],
        }
    Raises SpotifyResolveError with a human-readable message on failure --
    callers can show that message directly to the user.
    """
    try:
        from spotify_scraper import SpotifyClient
    except ImportError as e:
        raise SpotifyResolveError(
            "spotifyscraper isn't installed yet. Run setup (run.bat) first, "
            "or `pip install spotifyscraper`."
        ) from e

    kind = _classify_url(url)

    try:
        with SpotifyClient() as client:
            if kind == "playlist":
                entity = _call_with_optional_max_tracks(client.get_playlist, url, max_tracks)
            elif kind == "album":
                entity = _call_with_optional_max_tracks(client.get_album, url, max_tracks)
            else:
                entity = client.get_track(url)
    except SpotifyResolveError:
        raise
    except ImportError:
        raise
    except Exception as e:
        raise SpotifyResolveError(
            f"Spotify wouldn't give up that {kind}'s data ({e.__class__.__name__}: {e}). "
            "It may be private, region-locked, or Spotify changed something on their "
            "end. You can also paste an Exportify CSV instead (see the link below the "
            "URL box)."
        ) from e

    name = _get(entity, "name", "title", default=kind.title())
    owner = _get(entity, "owner")
    owner_name = _get(owner, "display_name", "name") if owner is not None else None
    cover_art = _extract_cover(entity)

    if kind == "track":
        raw_tracks = [entity]
    else:
        raw_tracks = _get(entity, "tracks", default=[]) or []
        # Some shapes wrap the list one level deeper, e.g. {"items": [...]}
        if isinstance(raw_tracks, dict):
            raw_tracks = raw_tracks.get("items") or raw_tracks.get("tracks") or []
        # Playlist.tracks holds PlaylistTrack wrappers (.track/.added_at/
        # .added_by); Album.tracks already holds plain Track objects. Unwrap
        # unconditionally -- it's a no-op for anything that isn't wrapped.
        raw_tracks = [_unwrap_playlist_track(t) for t in raw_tracks]

    tracks = [_normalize_track(t, i + 1) for i, t in enumerate(raw_tracks)]

    if not tracks:
        raise SpotifyResolveError(
            "That link resolved, but no tracks came back with it -- it might be "
            "empty, private, or region-locked. An Exportify CSV export is a "
            "reliable fallback (link below the URL box)."
        )

    if not cover_art:
        # Some playlists genuinely have no custom cover of their own even
        # though every track under them does -- borrow the first one rather
        # than showing a blank hero image.
        cover_art = next((t["cover_art"] for t in tracks if t.get("cover_art")), None)

    # How many tracks came back with zero image data of their own, before
    # any backfill -- this is the real diagnostic signal. spotifyscraper has
    # two internal paths for playlist tracks: a rich one with full per-track
    # album art, and a sparse fallback (used when the rich request fails for
    # any reason) that hardcodes empty images for every track, since
    # Spotify's own embed widget never shows per-track art either. When that
    # happens there's no per-track art to recover -- so every track missing
    # its own cover_art gets the playlist/album cover as a stand-in, which
    # is still correct far more often than not (most playlists are
    # single-album or close to it) and means downloaded files still get
    # *something* real embedded instead of nothing.
    tracks_missing_cover_url = sum(1 for t in tracks if not t.get("cover_art"))
    if cover_art and tracks_missing_cover_url:
        for t in tracks:
            if not t.get("cover_art"):
                t["cover_art"] = cover_art

    return {
        "source": "spotify",
        "type": kind,
        "name": name,
        "owner": owner_name,
        "cover_art": cover_art,
        "tracks": tracks,
        "tracks_missing_cover_url": tracks_missing_cover_url,
    }


def _call_with_optional_max_tracks(fn, url, max_tracks):
    """The installed spotifyscraper version might or might not accept
    max_tracks as a kwarg -- try, then fall back to calling without it."""
    try:
        return fn(url, max_tracks=max_tracks)
    except TypeError:
        return fn(url)


_BROWSER_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
}


def _headers_for(referer: str) -> dict:
    """Browser headers plus a Referer/Origin claiming the request came from
    the site itself -- a lot of image CDNs hotlink-block on exactly this,
    independent of User-Agent."""
    h = dict(_BROWSER_HEADERS)
    if referer:
        h["Referer"] = referer
        h["Origin"] = referer.rstrip("/")
    return h


def fetch_cover_bytes(track_meta: dict) -> bytes | None:
    """Best-effort direct download of a track's cover art, for embedding.
    Uses plain httpx/requests rather than the scraper's own download_cover()
    helper so it works whether or not the `spotifyscraper[media]` extra is
    installed. Raises the underlying exception on failure (rather than
    swallowing it) so the caller can log exactly what went wrong -- an
    HTTP status code here is the single most useful diagnostic for this."""
    url = track_meta.get("cover_art")
    if not url:
        return None
    headers = _headers_for("https://open.spotify.com/")
    try:
        import httpx
        resp = httpx.get(url, timeout=15, follow_redirects=True, headers=headers)
        resp.raise_for_status()
        return resp.content
    except ImportError:
        pass
    import requests
    resp = requests.get(url, timeout=15, headers=headers)
    resp.raise_for_status()
    return resp.content


# --------------------------------------------------------------------------
# Fallback path: Exportify CSV
# --------------------------------------------------------------------------

def parse_exportify_csv(file_bytes: bytes, display_name: str = "Playlist") -> dict:
    """Same normalized shape as resolve_spotify_url(), sourced from an
    Exportify (https://exportify.net) CSV export instead of live scraping."""
    text = file_bytes.decode("utf-8-sig", errors="replace")
    reader = csv.DictReader(io.StringIO(text))

    tracks = []
    for i, row in enumerate(reader, start=1):
        title = (row.get("Track Name") or "").strip()
        if not title:
            continue
        album = (row.get("Album Name") or "").strip()
        artists_raw = (row.get("Artist Name(s)") or "").strip()
        artist_list = [a.strip() for a in artists_raw.split(";") if a.strip()] or ["Unknown Artist"]
        first_artist = artist_list[0]
        all_artists = ", ".join(artist_list)
        release_date = (row.get("Album Release Date") or "").strip()
        year = release_date[:4] if release_date else None

        duration_ms = None
        for key in ("Track Duration (ms)", "Duration (ms)"):
            if row.get(key):
                try:
                    duration_ms = int(float(row[key]))
                except ValueError:
                    pass
                break

        explicit_raw = (row.get("Explicit") or row.get("explicit") or "").strip().lower()
        explicit = explicit_raw in ("true", "1", "yes")

        tracks.append({
            "index": i,
            "title": title,
            "first_artist": first_artist,
            "all_artists": all_artists,
            "album": album,
            "year": year,
            "duration_ms": duration_ms,
            "explicit": explicit,
            "preview_url": None,  # Exportify CSVs don't carry a preview clip URL
            "cover_art": (row.get("Album Image URL") or "").strip() or None,
            "safe_name": make_safe_name(first_artist, title),
        })

    if not tracks:
        raise SpotifyResolveError(
            "That CSV didn't have any recognizable tracks in it. Make sure it's "
            "an unmodified export from exportify.net (needs a 'Track Name' column)."
        )

    cover_art = next((t["cover_art"] for t in tracks if t.get("cover_art")), None)
    tracks_missing_cover_url = sum(1 for t in tracks if not t.get("cover_art"))
    if cover_art and tracks_missing_cover_url:
        for t in tracks:
            if not t.get("cover_art"):
                t["cover_art"] = cover_art

    return {
        "source": "csv",
        "type": "playlist",
        "name": display_name,
        "owner": None,
        "cover_art": cover_art,
        "tracks": tracks,
        "tracks_missing_cover_url": tracks_missing_cover_url,
    }
