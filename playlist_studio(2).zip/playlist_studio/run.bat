@echo off
setlocal
cd /d "%~dp0"

echo ============================================
echo   Playlist Studio - setup + launch
echo ============================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [!] Python was not found on your PATH.
    echo     Install it from https://python.org/downloads
    echo     ^(tick "Add python.exe to PATH" during install^), then run this again.
    pause
    exit /b 1
)

where ffmpeg >nul 2>nul
if errorlevel 1 (
    echo [!] ffmpeg wasn't found on your PATH. Every format needs it to convert/tag files.
    echo     Grab a build from https://www.gyan.dev/ffmpeg/builds/ ^(the "essentials" zip^),
    echo     unzip it somewhere, and add its \bin folder to your PATH.
    echo     Continuing setup anyway in case it's just not detected yet...
    echo.
)

echo Installing/updating dependencies ^(first run takes a minute, later runs are instant^)...
python -m pip install --upgrade pip >nul 2>nul
python -m pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo [!] Dependency install failed -- see the error above.
    pause
    exit /b 1
)

echo.
echo Starting Playlist Studio...
echo.
python launch.py
if errorlevel 1 (
    echo.
    echo [!] Playlist Studio exited with an error -- see above.
    pause
)
