"""
app.py

Local Flask server for Playlist Studio. Everything runs on 127.0.0.1 --
this is a single-user local tool, not a hosted service. Launch it via
run.bat (or `python launch.py` directly), not by deploying it anywhere.
"""

import os
import re
import subprocess
import sys
import threading
import uuid
from urllib.parse import urlparse

from flask import Flask, jsonify, render_template, request

import downloader
import spotify_meta

app = Flask(__name__)

JOBS = {}
JOBS_LOCK = threading.Lock()

DEFAULT_OUTPUT_ROOT = os.path.join(os.getcwd(), "downloads")


def _sanitize_folder_name(name: str) -> str:
    return spotify_meta.sanitize_filename(name or "") or "Playlist"


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/environment")
def api_environment():
    return jsonify(downloader.check_environment())


def _is_youtube_url(url: str) -> bool:
    host = urlparse(url).netloc.lower()
    return host.endswith("youtube.com") or host.endswith("youtu.be") or host.endswith("music.youtube.com")


@app.route("/api/resolve", methods=["POST"])
def api_resolve():
    data = request.get_json(silent=True) or {}
    url = (data.get("url") or "").strip()
    if not url:
        return jsonify({"error": "Paste a Spotify or YouTube link first."}), 400

    try:
        if _is_youtube_url(url):
            resolved = downloader.resolve_youtube_url(url)
        else:
            resolved = spotify_meta.resolve_spotify_url(url)
    except (spotify_meta.SpotifyResolveError, downloader.YouTubeResolveError) as e:
        return jsonify({"error": str(e)}), 422
    except Exception as e:
        return jsonify({"error": f"Unexpected error resolving that link: {e}"}), 500

    resolved["suggested_output"] = os.path.join(
        DEFAULT_OUTPUT_ROOT, _sanitize_folder_name(resolved["name"])
    )
    return jsonify(resolved)


@app.route("/api/resolve_csv", methods=["POST"])
def api_resolve_csv():
    file = request.files.get("file")
    if not file or not file.filename:
        return jsonify({"error": "No file received."}), 400
    display_name = os.path.splitext(file.filename)[0]
    try:
        resolved = spotify_meta.parse_exportify_csv(file.read(), display_name=display_name)
    except spotify_meta.SpotifyResolveError as e:
        return jsonify({"error": str(e)}), 422
    except Exception as e:
        return jsonify({"error": f"Unexpected error reading that CSV: {e}"}), 500

    resolved["suggested_output"] = os.path.join(
        DEFAULT_OUTPUT_ROOT, _sanitize_folder_name(resolved["name"])
    )
    return jsonify(resolved)


@app.route("/api/download", methods=["POST"])
def api_download():
    data = request.get_json(silent=True) or {}
    tracks = data.get("tracks") or []
    if not tracks:
        return jsonify({"error": "No tracks to download."}), 400

    playlist_name = data.get("playlist_name") or "Playlist"
    out_dir = (data.get("output_dir") or "").strip() or os.path.join(
        DEFAULT_OUTPUT_ROOT, _sanitize_folder_name(playlist_name)
    )

    scan_dirs_raw = data.get("scan_dirs") or []
    if isinstance(scan_dirs_raw, str):
        scan_dirs_raw = re.split(r"[\n;]+", scan_dirs_raw)
    scan_dirs = [s.strip() for s in scan_dirs_raw if s.strip()]

    audio_format = data.get("format", "mp3")
    if audio_format not in ("mp3", "flac", "m4a", "opus", "wav"):
        return jsonify({"error": f"Unsupported format: {audio_format}"}), 400

    try:
        threads = int(data.get("threads", 3))
    except (TypeError, ValueError):
        threads = 3
    threads = max(1, min(threads, 8))

    try:
        request_delay = float(data.get("request_delay", 0.5))
    except (TypeError, ValueError):
        request_delay = 0.5
    request_delay = max(0.0, min(request_delay, 5.0))

    options = {
        "format": audio_format,
        "quality": str(data.get("quality", "0")),
        "threads": threads,
        "cookies_browser": (data.get("cookies_browser") or "none").strip().lower(),
        "request_delay": request_delay,
        "smart_match": bool(data.get("smart_match", True)),
        "avoid_clean_edits": bool(data.get("avoid_clean_edits", True)),
    }

    job_id = uuid.uuid4().hex[:12]
    with JOBS_LOCK:
        JOBS[job_id] = {
            "id": job_id,
            "status": "queued",
            "playlist_name": playlist_name,
            "output_dir": out_dir,
            "total": len(tracks),
            "completed": 0,
            "failed_count": 0,
            "sorted_in": 0,
            "cancel_requested": False,
            "failed_tracks": [],
            "log": ["Job queued."],
            "tracks": {
                str(t["index"]): {
                    "title": t.get("title", "Unknown"),
                    "artist": t.get("first_artist", "Unknown Artist"),
                    "cover_art": t.get("cover_art"),
                    "status": "queued",
                    "percent": 0,
                }
                for t in tracks
            },
        }

    thread = threading.Thread(
        target=downloader.run_job,
        args=(job_id, tracks, out_dir, scan_dirs, options, JOBS, JOBS_LOCK),
        kwargs={"playlist_name": playlist_name},
        daemon=True,
    )
    thread.start()

    return jsonify({"job_id": job_id})


@app.route("/api/progress/<job_id>")
def api_progress(job_id):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
        if not job:
            return jsonify({"error": "Unknown job."}), 404
        snapshot = {
            "id": job["id"],
            "status": job["status"],
            "playlist_name": job["playlist_name"],
            "output_dir": job["output_dir"],
            "total": job["total"],
            "completed": job["completed"],
            "failed_count": job["failed_count"],
            "sorted_in": job["sorted_in"],
            "failed_tracks": list(job["failed_tracks"]),
            "m3u_path": job.get("m3u_path"),
            "log": list(job["log"][-40:]),
            "tracks": {k: dict(v) for k, v in job["tracks"].items()},
        }
    return jsonify(snapshot)


@app.route("/api/pick_folder", methods=["POST"])
def api_pick_folder():
    """Pop a real native folder-picker dialog. This works because the
    Flask server IS the user's own machine -- there's no browser sandboxing
    to fight, unlike a normal hosted website."""
    data = request.get_json(silent=True) or {}
    initial = (data.get("initial") or "").strip() or os.getcwd()
    try:
        import tkinter as tk
        from tkinter import filedialog
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        chosen = filedialog.askdirectory(initialdir=initial if os.path.isdir(initial) else os.getcwd())
        root.destroy()
        if not chosen:
            return jsonify({"cancelled": True})
        return jsonify({"path": chosen})
    except Exception as e:
        return jsonify({"error": f"Native folder picker isn't available here ({e}). Type the path instead."}), 501


@app.route("/api/cancel/<job_id>", methods=["POST"])
def api_cancel(job_id):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
        if not job:
            return jsonify({"error": "Unknown job."}), 404
        job["cancel_requested"] = True
    return jsonify({"ok": True})


@app.route("/api/open_folder", methods=["POST"])
def api_open_folder():
    data = request.get_json(silent=True) or {}
    path = (data.get("path") or "").strip()
    if not path or not os.path.isdir(path):
        return jsonify({"error": "That folder doesn't exist yet -- it's created on first download."}), 404
    try:
        if os.name == "nt":
            os.startfile(path)  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5757, debug=False, threaded=True)
