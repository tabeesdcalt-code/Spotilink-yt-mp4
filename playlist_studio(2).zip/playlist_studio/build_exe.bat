@echo off
setlocal
cd /d "%~dp0"

echo ================================================
echo   Building PlaylistStudio.exe with PyInstaller
echo ================================================
echo.
echo A Windows .exe has to be built ON Windows -- PyInstaller doesn't
echo cross-compile. That's exactly what this script does, locally,
echo in about 1-3 minutes. The result is a single file you can move
echo anywhere and double-click, no Python install required to run it
echo (ffmpeg still needs to be on PATH the first time it runs).
echo.
echo Note: this produces a 64-bit (x64) build if you have 64-bit Python
echo installed, which is standard on any Windows PC from the last
echo decade-plus. True 32-bit (x86) Windows is essentially extinct --
echo if you specifically need it, install 32-bit Python and rerun this.
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [!] Python not found. Run run.bat first, or install Python from python.org.
    pause
    exit /b 1
)

python -m pip install -r requirements.txt
python -m pip install pyinstaller

echo.
echo Building...
echo.

python -m PyInstaller ^
  --name PlaylistStudio ^
  --onefile ^
  --add-data "templates;templates" ^
  --add-data "static;static" ^
  --collect-all spotify_scraper ^
  --collect-all yt_dlp ^
  --hidden-import mutagen ^
  launch.py

echo.
if exist "dist\PlaylistStudio.exe" (
    echo Done -- your app is at: dist\PlaylistStudio.exe
    echo.
    echo That single file is the whole app now. Copy it wherever you like.
    echo A console window will appear behind the app the first few times you
    echo run it -- that's deliberate, so you can see any setup errors ^(like
    echo a missing ffmpeg^). Once you've confirmed it runs clean, you can
    echo rebuild adding --windowed to this script's PyInstaller command to
    echo hide that console for good.
) else (
    echo [!] No exe showed up -- scroll up for the PyInstaller error.
)
echo.
pause
